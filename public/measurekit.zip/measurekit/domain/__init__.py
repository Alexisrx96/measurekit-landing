"""Domain layer for measurekit."""
